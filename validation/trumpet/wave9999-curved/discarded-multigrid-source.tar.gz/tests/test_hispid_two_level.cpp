// Coupled, admissible manufactured correction on the actual production backend.
// This is a linear-algebra control, not a resolved physical wave experiment.
#include "../src/HiSpID_solver.cpp"
#include <cstdio>
static bool transfer_control(){
 const int fine[3]={8,10,16},coarse[3]={4,5,8};AzimuthalCoarseTransfer transfer(coarse,fine);
 const int nf=4*fine[0]*fine[1]*fine[2],nc=4*coarse[0]*coarse[1]*coarse[2];
 auto fill=[](const int*n,bool high,bool physical){
  std::vector<double>out(4*n[0]*n[1]*n[2],0.);
  for(int j=0;j<n[1];j++)for(int i=0;i<n[0];i++)for(int v=0;v<4;v++){
   double t=.5*(1-std::cos(Pi*(i+.5)/n[0])),z=-std::cos(Pi*(j+.5)/n[1]),p=(v+1)*t*t*std::pow(1-z*z,2);
   if(physical){for(int k=0;k<n[2];k++){double phi=2*Pi*k/n[2];out[4*(i+n[0]*(j+n[1]*k))+v]=p*(std::cos(2*phi)+.3*std::cos(4*phi)+.1*std::sin(phi)+(high?.2*std::cos(5*phi):0));}}
   else{
    for(auto entry:{std::pair<int,double>{2,1.},{4,.3},{n[2]/2+1,.1}}){int m=entry.first<=n[2]/2?entry.first:entry.first-n[2]/2;out[4*(i+n[0]*(j+n[1]*entry.first))+v]=p*entry.second/std::sqrt((m==0||m==n[2]/2?1.:2.)/n[2]);}
    if(high)out[4*(i+n[0]*(j+n[1]*5))+v]=p*.2/std::sqrt(2./n[2]);
   }
  }return out;
 };
 auto unknown=fill(fine,true,false),physical=fill(fine,true,true),expected_unknown=fill(coarse,false,false),expected_physical=fill(coarse,false,true),expected_fine=fill(fine,false,false);
 auto u=puncture::upload(unknown,"transfer witness modal"),r=puncture::upload(physical,"transfer witness physical");
 puncture::View cu("coarse modal witness",nc),cr("coarse physical witness",nc),prolonged("prolonged witness",nf);
 transfer.restrict_values(u,cu);transfer.restrict_residual(r,cr);transfer.prolong(cu,prolonged);
 std::vector<double>actual_u(nc),actual_r(nc),actual_f(nf);puncture::download(cu,actual_u.data());puncture::download(cr,actual_r.data());puncture::download(prolonged,actual_f.data());
 double error=0;auto compare=[&](const auto&a,const auto&b){for(size_t i=0;i<a.size();i++)error=std::max(error,std::abs(a[i]-b[i])/(1+std::abs(b[i])));};
 compare(actual_u,expected_unknown);compare(actual_r,expected_physical);compare(actual_f,expected_fine);
 std::printf("two-level Fourier/tensor transfer independent oracle: %.17g\n",error);return error<3e-12;
}
int main(){
 puncture::initialize();if(!transfer_control())return 1;HiSpID_Config c;HiSpID_default_config(&c);
 c.n[0]=128;c.n[1]=96;c.n[2]=4;c.memory_limit_mib=8192;
 c.krylov_restart=32;c.max_krylov=240;c.far_radius=0;c.conformal_choice=1;
 c.inner_flatten=1;c.inner_min[0]=.1;c.inner_max[0]=.2;c.inner_min[1]=c.inner_max[1]=0;
 c.hole[0]={};c.hole[0].mass=1;c.hole[0].spin[2]=.9999;
 c.hole[1]={};c.hole[1].center[2]=-16;
 std::unique_ptr<HiSpID_Data,HiSpID_Delete>s(HiSpID_create_with_seed_family(&c,HISPID_SEED_LIU,PUNCTURE_KOKKOS,0,0));
 if(!s){std::fprintf(stderr,"%s\n",HiSpID_last_error());return 1;}
 std::vector<double>known(s->ntotal,0.),rhs(s->ntotal),x,action(s->ntotal),residual(s->ntotal);
 for(int j=0;j<c.n[1];j++)for(int i=0;i<c.n[0];i++){
  const double sigma=.5*(1-std::cos(Pi*(i+.5)/c.n[0])),zeta=-std::cos(Pi*(j+.5)/c.n[1]);
  const double p=1e-8*sigma*sigma*std::pow(1-zeta*zeta,2);
  for(int v=0;v<4;v++)known[4*(i+c.n[0]*j)+v]=p*(v? .2*v:1.);
 }
 // Freeze the same zero base for all Jacobian applications.
 s->device->fields(s->values.data(),true);jvp(*s,known.data(),rhs.data());
 auto M=preconditioner(*s);bool ok=linear_solve(*s,M,rhs,x,1e-7,PK_GMRES);
 jvp(*s,x.data(),action.data());for(size_t i=0;i<rhs.size();i++)residual[i]=rhs[i]-action[i];
 double true_relative=norm2v(residual)/norm2v(rhs),error=0,scale=0;
 std::vector<Fields>a,b;fields(*s,known.data(),a,false);fields(*s,x.data(),b,false);
 for(size_t i=0;i<a.size();i++)for(int v=0;v<4;v++)for(int d=0;d<4;d++){
  error+=std::pow(a[i][v][d]-b[i][v][d],2);scale+=a[i][v][d]*a[i][v][d];
 }
 double field_error=std::sqrt(error/scale);
 std::printf("two-level coupled witness: passed=%d iterations=%d true_relative=%.17g field_relative=%.17g levels=%d\n",ok,s->diag.krylov_iterations,true_relative,field_error,s->coarse?(s->coarse->coarse?3:2):1);
 return ok&&s->coarse&&s->coarse->coarse&&true_relative<=1e-7&&field_error<1e-4?0:1;
}
