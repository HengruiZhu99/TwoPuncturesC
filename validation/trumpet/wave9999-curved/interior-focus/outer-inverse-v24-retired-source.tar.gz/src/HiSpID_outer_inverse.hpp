#pragma once
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <vector>
namespace hispid {
// Approximate inverse only: B_new = B D with strictly positive modal D.
// The radius is the minimum distance of this confocal shell from either focus.
// Keep the native residual, Jacobian, factors and every boundary row unchanged.
struct OuterInverseStats { int reference=-1,changed=0; double minimum_damping=1; };
inline OuterInverseStats damp_outer_inverse(std::vector<double>&scale,int na,int nb,int np,
                                           const std::vector<double>&radius,double onset){
 OuterInverseStats stats;
 if(onset==0)return stats;
 if(!(onset>0)||!std::isfinite(onset)||int(radius.size())!=na||scale.size()!=size_t(4)*na*nb*np)
  throw std::runtime_error("invalid outer inverse damping configuration");
 for(int i=0;i<na;i++){
  if(!std::isfinite(radius[i])||radius[i]<0||(i&&radius[i]<=radius[i-1]))throw std::runtime_error("invalid outer inverse radial shells");
  if(radius[i]<=onset)stats.reference=i;
 }
 if(stats.reference<1)throw std::runtime_error("outer inverse onset must enclose both possible focus rows");
 if(stats.reference==na-1)return stats;
 for(int slot=0;slot<np;slot++){
  const int mode=slot<=np/2?slot:slot-np/2;if(mode>4)continue;
  for(int j=0;j<nb;j++)for(int v=1;v<4;v++){
   const double reference=std::abs(scale[4*(stats.reference+na*(j+nb*slot))+v]);
   if(!(reference>0)||!std::isfinite(reference))throw std::runtime_error("invalid outer inverse reference scale");
   for(int i=stats.reference+1;i<na;i++){
    // C1 onset of tau; no RHS-dependent threshold or hard mode removal.
    const double u=(radius[i]-onset)/onset,w=u<=1?u*u/(1+u*u):1/(1+1/u/u);
    auto&s=scale[4*(i+na*(j+nb*slot))+v];const double original=s;
    s=std::copysign(std::hypot(s,reference*w),s);const double damping=original/s;
    if(!(damping>0&&damping<=1)||!std::isfinite(s))throw std::runtime_error("noninvertible outer inverse damping");
    stats.minimum_damping=std::min(stats.minimum_damping,damping);stats.changed++;
   }
  }
 }
 return stats;
}
}
