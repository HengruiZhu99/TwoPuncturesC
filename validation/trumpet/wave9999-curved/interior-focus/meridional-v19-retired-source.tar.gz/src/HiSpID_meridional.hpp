#ifndef HISPID_MERIDIONAL_HPP
#define HISPID_MERIDIONAL_HPP
#include "HiSpID_curved_preconditioner.hpp"
#include "HiSpID_modal_block.hpp"
namespace hispid {
// Axisymmetric cylindrical vector sector. Input/output factors differ:
// axial F0=-2(1-t), radial F1=F0*rho/[b(C+1)]. Each entry is divided by
// its OUTPUT factor, so off-diagonal entries retain Fsource/Ftarget.
struct MeridionalSymbol { ModalSymbol entry[2][2]; };
HISPID_GEOMETRY_INLINE MeridionalSymbol meridional_symbol(const Cached&g,
 double b,double axial,double y,double z){
 using J=JetT<double>;
 J x=J::variable(axial,1),Y=J::variable(y,2),Z=J::variable(z,3);
 J plus=sqrt((x+J(b))*(x+J(b))+Y*Y+Z*Z),minus=sqrt((x-J(b))*(x-J(b))+Y*Y+Z*Z);
 J C=(plus+minus)/J(2*b),eta=(plus-minus)/J(2*b),t=(C-J(1))/(C+J(1));
 J sigma=AxisDerivatives::radial_inverse(t);
 const double k=AxisDerivatives::angular_stretch,T=std::tanh(k),rho=std::sqrt(y*y+z*z);
 J e=eta*J(T),zeta=unary(e,std::atanh(e.v),1/(1-e.v*e.v),2*e.v/std::pow(1-e.v*e.v,2))/J(k);
 J f0=J(-2)*(J(1)-t),f1=f0/(J(b)*(C+J(1)));
 J basis[2][3]={{f0,J(0),J(0)},{J(0),f1*Y,f1*Z}};
 const double denominator[2]={f0.v,f1.v*rho},co=y/rho,si=z/rho;
 const J coordinates[2]={sigma-J(sigma.v),zeta-J(zeta.v)};
 MeridionalSymbol out;
 for(int target=0;target<2;target++)for(int source=0;source<2;source++){
  auto apply=[&](const J&P){
   J f[3];for(int v=0;v<3;v++)f[v]=basis[source][v]*P;
   double result[3]={};
   for(int a=0;a<3;a++)for(int v=0;v<3;v++)for(int d=0;d<10;d++){
    double jet=d==0?f[v].v:(d<4?f[v].d[d]:f[v].h[hessian_i(d-4)][hessian_j(d-4)]);
    result[a]+=g.vec[a][v][d]*jet;
   }
   return (target==0?result[0]:co*result[1]+si*result[2])/denominator[target];
  };
  auto&q=out.entry[target][source];q.zero=apply(J(1));
  for(int a=0;a<2;a++){q.first[a]=apply(coordinates[a]);q.second[a]=apply(coordinates[a]*coordinates[a]/J(2));}
  q.mixed=apply(coordinates[0]*coordinates[1]);
 }
 return out;
}
inline long double meridional_allocation_bound(int na,int nb){
 // Host LU/transfer, seven bands, permutations, focus banks, symbols and
 // bounded construction/copy buffers; includes the small device bridge.
 return 64.L*na*na*nb+1536.L*na*nb+64.L*na*na+1048576;
}
struct MeridionalInverse {
 ModalBlock block;
 int na,nb;
 MeridionalInverse(int a,int b,const std::vector<MeridionalSymbol>&symbols,
                   const std::vector<double>&geometric_scale):na(a),nb(b){
  if(symbols.size()!=size_t(na*nb)||geometric_scale.size()!=symbols.size())throw std::runtime_error("Invalid meridional symbol extent");
  auto&B=block;B.na=2*na;B.nb=nb;B.banded_coupling=true;B.coupling_radius=3;
  const int width=2*na,N=width*nb;B.lu.assign(size_t(width)*N,0);B.transfer.resize(size_t(width)*N);
  B.lower.assign(7*N,0);B.upper.assign(7*N,0);B.permutation.resize(N);
  const double pi=std::acos(-1.),ha=pi/na,hb=pi/nb;
  for(int j=0;j<nb;j++)for(int i=0;i<na;i++)for(int target=0;target<2;target++){
   const int row=2*i+target;const double al=ha*(i+.5),be=hb*(j+.5),sa=.5*std::sin(al),sb=std::sin(be),saa=.5*std::cos(al),sbb=std::cos(be);
   for(int source=0;source<2;source++){
    const auto&q=symbols[i+na*j].entry[target][source];
    auto insert=[&](int di,int dj,double value){
     // Reflect in the PHYSICAL grid before interleaving components.
     int ii=i+di,jj=j+dj;if(ii<0)ii=-ii-1;if(ii>=na)ii=2*na-ii-1;
     if(jj<0)jj=-jj-1;if(jj>=nb)jj=2*nb-jj-1;
     int col=2*ii+source;value*=geometric_scale[i+na*j];
     if(jj==j)B.lu[(size_t(j)*width+row)*width+col]+=value;
     else if(std::abs(col-row)<=3&&jj==j-1)B.lower[7*(j*width+row)+col-row+3]+=value;
     else if(std::abs(col-row)<=3&&jj==j+1)B.upper[7*(j*width+row)+col-row+3]+=value;
     else throw std::runtime_error("Invalid coupled meridional band");
    };
    const double aa=q.second[0]/(sa*sa),da=q.first[0]/sa-q.second[0]*saa/(sa*sa*sa);
    const double bb=q.second[1]/(sb*sb),db=q.first[1]/sb-q.second[1]*sbb/(sb*sb*sb),mixed=q.mixed/(4*sa*sb*ha*hb);
    insert(0,0,q.zero-2*aa/(ha*ha)-2*bb/(hb*hb));
    insert(1,0,aa/(ha*ha)+da/(2*ha));insert(-1,0,aa/(ha*ha)-da/(2*ha));
    insert(0,1,bb/(hb*hb)+db/(2*hb));insert(0,-1,bb/(hb*hb)-db/(2*hb));
    insert(1,1,mixed);insert(-1,-1,mixed);insert(1,-1,-mixed);insert(-1,1,-mixed);
   }
  }
  if(HISPID_FOCUS_TAU){
   B.focus_endpoint.assign(size_t(2*focus_rank)*N,0);B.focus_rows.resize(2*focus_rank);
   for(int component=0;component<2;component++){
    auto weights=focus_weights(na,nb,component);
    for(int q=0;q<focus_rank;q++){
     const int row=2*q+component;B.focus_rows[row]=2*focus_row(q,na,nb)+component;
     for(int p=0;p<na*nb;p++)B.focus_endpoint[size_t(row)*N+2*p+component]=weights[size_t(q)*na*nb+p];
    }
   }
  }
  B.factor(-1,false);
 }
 void solve(double*x)const{block.solve_contiguous(x);}
};
}
#endif
