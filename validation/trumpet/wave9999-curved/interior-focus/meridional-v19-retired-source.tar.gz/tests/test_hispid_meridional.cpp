#include "../src/HiSpID_meridional.hpp"
#include <cstdio>
int main(){
 hispid::Cached flat{};
 for(int i=0;i<3;i++)for(int j=0;j<3;j++)for(int d=4;d<10;d++){
  int a=hispid::hessian_i(d-4)-1,b=hispid::hessian_j(d-4)-1;
  if(i==j&&a==b)flat.vec[i][j][d]=1;
  if((a==i&&b==j)||(a==j&&b==i))flat.vec[i][j][d]+=1./3;
 }
 double error=0;
 for(double sigma:{.008,.13,.65,.97})for(double zeta:{-.995,-.71,.13,.97}){
  using J=hispid::JetT<double>;J S=J::variable(sigma,1),Z=J::variable(zeta,2);
  double ts,tss;hispid::AxisDerivatives::radial_forward(sigma,ts,tss);
  J t=unary(S,hispid::AxisDerivatives::radial_t(sigma),ts,tss),C=(J(1)+t)/(J(1)-t);
  const double b=.5,k=hispid::AxisDerivatives::angular_stretch;
  J eta=tanh(J(k)*Z)/J(std::tanh(k)),x=J(b)*C*eta,rho=sqrt(J(b*b)*(C*C-J(1))*(J(1)-eta*eta));
  J factor[2]={J(-2)*(J(1)-t),J(-2)*(J(1)-t)*rho/(J(b)*(C+J(1)))};
  auto q=hispid::meridional_symbol(flat,b,x.v,rho.v,0);
  J fields[4][2]={{x*rho*rho,J(0)},{J(0),x*rho},{x*x,J(0)},{J(0),rho*rho*rho}};
  double expected[4][2]={{4*x.v,2*rho.v/3},{2./3,0},{8./3,0},{0,32*rho.v/3}};
  for(int n=0;n<4;n++)for(int target=0;target<2;target++){
   double result=0,scale=1+std::abs(expected[n][target]);
   for(int source=0;source<2;source++){
    J P=fields[n][source]/factor[source];const auto&a=q.entry[target][source];
    double parts[6]={a.zero*P.v,a.first[0]*P.d[1],a.first[1]*P.d[2],a.second[0]*P.h[1][1],a.second[1]*P.h[2][2],a.mixed*P.h[1][2]};
    for(double v:parts){result+=factor[target].v*v;scale+=std::abs(factor[target].v*v);}
   }
   error=std::max(error,std::abs(result-expected[n][target])/scale);
  }
 }
 printf("coupled meridional Cartesian cross-action witness: %.17g\n",error);if(error>1e-9)return 1;
 const int a=7,b=9,width=2*a,N=width*b;
 hispid::ModalBlock B;B.na=width;B.nb=b;B.banded_coupling=true;B.coupling_radius=3;
 B.lu.assign(width*N,0);B.transfer.resize(width*N);B.lower.assign(7*N,0);B.upper.assign(7*N,0);B.permutation.resize(N);
 std::vector<double>A(N*N,0),exact(N),rhs(N,0);
 for(int j=0;j<b;j++)for(int i=0;i<width;i++){
  int row=j*width+i;exact[row]=std::sin(.37*row)+.1*std::cos(.21*row);
  for(int col=0;col<width;col++)A[row*N+j*width+col]=B.lu[row*width+col]=i==col?6.:.03*std::cos(i+3*col);
  for(int col=std::max(0,i-3);col<=std::min(width-1,i+3);col++){
   if(j)A[row*N+(j-1)*width+col]=B.lower[7*row+col-i+3]=.1+.02*(i-col);
   if(j+1<b)A[row*N+(j+1)*width+col]=B.upper[7*row+col-i+3]=-.08+.01*(i-col);
  }
 }
 const int rank=2*hispid::focus_rank;B.focus_rows.resize(rank);B.focus_endpoint.assign(rank*N,0);
 for(int c=0;c<2;c++){
  auto W=hispid::focus_weights(a,b,c);
  for(int q=0;q<hispid::focus_rank;q++){
   int border=2*q+c,row=2*hispid::focus_row(q,a,b)+c;B.focus_rows[border]=row;
   std::fill(A.begin()+row*N,A.begin()+(row+1)*N,0.);
   for(int p=0;p<a*b;p++)A[row*N+2*p+c]=B.focus_endpoint[border*N+2*p+c]=W[q*a*b+p];
  }
 }
 for(int i=0;i<N;i++)for(int j=0;j<N;j++)rhs[i]+=A[i*N+j]*exact[j];
 B.factor(-1,false);B.solve_contiguous(rhs.data());double inverse=0;
 for(int i=0;i<N;i++)inverse=std::max(inverse,std::abs(rhs[i]-exact[i]));
 printf("seven-band interleaved inverse with coupled focus rows: %.17g\n",inverse);if(inverse>1e-10)return 1;
 return 0;
}
