// Coupled, admissible manufactured correction on the actual production backend.
// This is a linear-algebra control, not a resolved physical wave experiment.
#include "../src/HiSpID_solver.cpp"
#include <cstdio>
int main(int argc,char**argv){
 const double separation=argc==2?std::stod(argv[1]):16.;
 if(argc>2||!std::isfinite(separation)||separation<=0)return 1;
 puncture::initialize();HiSpID_Config c;HiSpID_default_config(&c);
 c.n[0]=128;c.n[1]=96;c.n[2]=4;c.memory_limit_mib=8192;
 c.krylov_restart=32;c.max_krylov=240;c.far_radius=0;c.conformal_choice=1;
 c.inner_flatten=1;c.inner_min[0]=.1;c.inner_max[0]=.2;c.inner_min[1]=c.inner_max[1]=0;
 c.hole[0]={};c.hole[0].mass=1;c.hole[0].spin[2]=.9999;
 c.hole[1]={};c.hole[1].center[2]=-separation;
 std::unique_ptr<HiSpID_Data,HiSpID_Delete>s(HiSpID_create_with_seed_family(&c,HISPID_SEED_LIU,PUNCTURE_KOKKOS,0,0));
 if(!s){std::fprintf(stderr,"%s\n",HiSpID_last_error());return 1;}
 std::vector<double>known(s->ntotal,0.),rhs(s->ntotal),x,action(s->ntotal),residual(s->ntotal);
 for(int j=0;j<c.n[1];j++)for(int i=0;i<c.n[0];i++){
  const double sigma=.5*(1-std::cos(Pi*(i+.5)/c.n[0])),zeta=-std::cos(Pi*(j+.5)/c.n[1]);
  const double p=1e-8*sigma*sigma*std::pow(1-zeta*zeta,2);
  for(int v=0;v<4;v++)known[4*(i+c.n[0]*j)+v]=p*(v? .2*v:1.);
 }
 // Freeze the same zero base for all Jacobian applications.
 s->device->fields(s->values.data(),true);jvp(*s,known.data(),rhs.data());
 auto M=preconditioner(*s);double start=puncture::seconds();bool ok=linear_solve(*s,M,rhs,x,1e-7,PK_GMRES);
 double elapsed=puncture::seconds()-start;jvp(*s,x.data(),action.data());for(size_t i=0;i<rhs.size();i++)residual[i]=rhs[i]-action[i];
 double true_relative=norm2v(residual)/norm2v(rhs),error=0,scale=0;
 std::vector<Fields>a,b;fields(*s,known.data(),a,false);fields(*s,x.data(),b,false);
 for(size_t i=0;i<a.size();i++)for(int v=0;v<4;v++)for(int d=0;d<4;d++){
  error+=std::pow(a[i][v][d]-b[i][v][d],2);scale+=a[i][v][d]*a[i][v][d];
 }
 double field_error=std::sqrt(error/scale);
 std::printf("constraint-block coupled witness: passed=%d iterations=%d true_relative=%.17g field_relative=%.17g seconds=%.17g focus_separation=%.17g preconditioner=%s\n",ok,s->diag.krylov_iterations,true_relative,field_error,elapsed,separation,HiSpID_preconditioner_description(s.get()));
 if(HISPID_MERIDIONAL_PRECONDITIONER){
  const int N=c.n[0]*c.n[1],np=c.n[2],sine=np/2+1;const double root2=std::sqrt(2.);
  auto d=device_preconditioner(M);MeridionalBridge bridge(*s,d);
  std::vector<double>modal(s->ntotal,0.),physical(s->ntotal,0.),pair(2*N),expected(s->ntotal),actual(s->ntotal);
  for(int row=0;row<N;row++){
   double ax=.01*std::sin(.17*row),rad=.02*std::cos(.23*row),other=.03*std::sin(.19*row),tor=.04*std::cos(.13*row);
   pair[2*row]=ax;pair[2*row+1]=rad;
   modal[4*row+1]=ax;modal[4*(row+N)+2]=(rad+other)/root2;modal[4*(row+N*sine)+3]=(rad-other)/root2;
   modal[4*(row+N*sine)+2]=-tor/root2;modal[4*(row+N)+3]=tor/root2;
  }
  // Independently synthesize native equations from prescribed scaled modal
  // RHS values, including radial-complement and toroidal contamination.
  for(int row=0;row<N;row++)for(int k=0;k<np;k++)for(int v=0;v<4;v++)for(int m=0;m<np;m++)
   physical[4*(row+N*k)+v]+=s->derivatives.inverse[k*np+m]*M.row_scale[4*(row+N*m)+v]*modal[4*(row+N*m)+v];
  s->meridional->solve(pair.data());double scale=norminf(pair);
  for(int i=0;i<s->ntotal;i++)expected[i]=scale*.1*std::sin(.11*i);
  auto input=puncture::upload(physical,"meridional bridge witness RHS"),output=puncture::upload(expected,"meridional bridge witness initial");
  for(int row=0;row<N;row++){
   expected[4*row+1]=pair[2*row];int y=4*(row+N)+2,z=4*(row+N*sine)+3;
   double complement=(expected[y]-expected[z])/root2;
   expected[y]=(pair[2*row+1]+complement)/root2;expected[z]=(pair[2*row+1]-complement)/root2;
  }
  bridge.apply(input,output);puncture::download(output,actual.data());
  double bridge_error=0;for(int i=0;i<s->ntotal;i++)bridge_error=std::max(bridge_error,std::abs(actual[i]-expected[i]));
  bridge_error/=scale;std::printf("meridional bridge restriction and complement witness: %.17g\n",bridge_error);
  if(bridge_error>1e-9)return 1;
 }
 return ok&&std::string(HiSpID_preconditioner_description(s.get()))==(HISPID_MERIDIONAL_PRECONDITIONER?"constraint_block_upper_triangular_meridional":"constraint_block_upper_triangular")&&true_relative<=1e-7&&field_error<1e-4?0:1;
}
