#ifndef HISPID_POLAR_PRECONDITIONER_HPP
#define HISPID_POLAR_PRECONDITIONER_HPP
#include "HiSpID_modal_block.hpp"
#include "HiSpID_curved_preconditioner.hpp"
#ifndef HISPID_SPECTRAL_POLAR_PRECONDITIONER
#define HISPID_SPECTRAL_POLAR_PRECONDITIONER 0
#endif
namespace hispid {
// Same modal approximate symbol, with exact polynomial polar derivatives.
// Transpose the block ordering: polar index is contiguous, radial FD couples
// adjacent blocks. The mixed derivative makes those couplings dense.
inline ModalBlock polar_spectral_block(int na,int nb,int mode,double separation,
                                     const ModalSymbol*symbols){
 ModalBlock block;block.na=nb;block.nb=na;block.dense_coupling=true;
 const size_t square=size_t(na)*nb*nb;const int N=na*nb;
 block.lu.assign(square,0);block.transfer.assign(square,0);
 block.lower.assign(square,0);block.upper.assign(square,0);block.permutation.resize(N);
 std::vector<double>d(nb*nb),dd(nb*nb);
 for(int j=0;j<nb;j++){
  long double s1=0,s2=0;for(int k=0;k<nb;k++)if(j!=k){
   auto a=chebyshev_offdiagonal<long double>(nb,j,k,1),b=chebyshev_offdiagonal<long double>(nb,j,k,2);
   d[j*nb+k]=a;dd[j*nb+k]=b;s1+=a;s2+=b;
  }d[j*nb+j]=-double(s1);dd[j*nb+j]=-double(s2);
 }
 const double pi=std::acos(-1.),h=pi/na;
 for(int i=0;i<na;i++)for(int j=0;j<nb;j++){
  const auto&q=symbols[i+na*j];const double alpha=h*(i+.5),s=.5*std::sin(alpha),ss=.5*std::cos(alpha);
  const double t=AxisDerivatives::radial_t(.5*(1-std::cos(alpha)));
  const double eta=AxisDerivatives::angular_eta(-std::cos(pi*(j+.5)/nb));
  const double metric=separation*separation*(4*t/((1-t)*(1-t))+1-eta*eta);
  auto add=[&](int di,int k,double value){
   int ii=i+di;if(ii<0)ii=0;if(ii>=na)ii=na-1;
   auto&bank=ii==i?block.lu:(ii<i?block.lower:block.upper);
   bank[(size_t(i)*nb+j)*nb+k]+=metric*value;
  };
  const double diffusion=q.second[0]/(s*s),drift=q.first[0]/s-q.second[0]*ss/(s*s*s);
  add(0,j,q.zero-2*diffusion/(h*h));
  add(-1,j,diffusion/(h*h)-drift/(2*h));add(1,j,diffusion/(h*h)+drift/(2*h));
  for(int k=0;k<nb;k++){
   add(0,k,q.first[1]*d[j*nb+k]+q.second[1]*dd[j*nb+k]);
   const double mixed=q.mixed*d[j*nb+k]/(2*h*s);
   add(-1,k,-mixed);add(1,k,mixed);
  }
 }
 if(HISPID_FOCUS_TAU){
  auto original=focus_weights(na,nb,mode);block.focus_endpoint.resize(original.size());
  for(int r=0;r<focus_rank;r++){
   int row=focus_row(r,na,nb);block.focus_rows.push_back(row/na+nb*(row%na));
   for(int i=0;i<na;i++)for(int j=0;j<nb;j++)block.focus_endpoint[r*N+j+nb*i]=original[r*N+i+na*j];
  }
 }
 return block;
}
// Conservative extra banks/workspace, including simultaneous host/device
// factor preparation and dense-Schur scratch; separate from the old inverse.
inline long double polar_spectral_device_bytes(int na,int nb,int np){
 const int groups=std::min(4,np/2)+1,slots=2*groups-1;
 return 40.L*groups*na*nb*nb+(192.L*slots+128.L*groups)*na*nb+1048576.L;
}
inline long double polar_spectral_total_bytes(int na,int nb,int np){
 const int groups=std::min(4,np/2)+1;
 return polar_spectral_device_bytes(na,nb,np)+40.L*groups*na*nb*nb+160.L*groups*na*nb+1048576.L;
}
}
#endif
