// Independent polynomial action and coupled host/device inverse bridge.
#include "../src/HiSpID_solver.cpp"
int main(int argc,char**argv){
 const int np=argc==2?std::stoi(argv[1]):16;if(np!=4&&np!=16)return 1;
 puncture::initialize();const int a=12,b=10,N=a*b,testmode=std::min(4,np/2);
 HiSpID_Data s;HiSpID_default_config(&s.local);s.local.n[0]=a;s.local.n[1]=b;s.local.n[2]=np;s.b=.5;
 s.derivatives.initialize(s.local.n);s.curved_symbols.resize(2*(np/2+1)*N);
 for(int m=0;m<=np/2;m++)for(int p=0;p<N;p++){
  const double sig=.5*(1-std::cos(Pi*((p%a)+.5)/a)),z=-std::cos(Pi*((p/a)+.5)/b);
  auto&q=s.curved_symbols[(2*m+1)*N+p];q.zero=-2.-.1*m;q.first[0]=.7*(1-2*sig);q.first[1]=-2.2*z;q.second[0]=.7*sig*(1-sig);q.second[1]=1.1*(1-z*z);q.mixed=.15*sig*(1-sig)*(1-z*z);
 }
 auto B=hispid::polar_spectral_block(a,b,testmode,s.b,s.curved_symbols.data()+(2*testmode+1)*N);
 std::vector<double>known(N),r(N),full(N*N);const double h=Pi/a;
 auto val=[](double sigma,double zeta){return (1+.3*sigma+sigma*sigma)*(1+zeta+zeta*zeta*zeta);};
 for(int i=0;i<a;i++)for(int j=0;j<b;j++)known[j+b*i]=val(.5*(1-std::cos(h*(i+.5))),-std::cos(Pi*(j+.5)/b));
 for(int i=0;i<a;i++)for(int j=0;j<b;j++)for(int k=0;k<b;k++){
  int row=j+b*i;full[row*N+k+b*i]=B.lu[(i*b+j)*b+k];
  if(i)full[row*N+k+b*(i-1)]=B.lower[(i*b+j)*b+k];
  if(i+1<a)full[row*N+k+b*(i+1)]=B.upper[(i*b+j)*b+k];
 }
 double action_error=0;
 for(int i=0;i<a;i++)for(int j=0;j<b;j++){
  int row=j+b*i;long double got=0;for(int k=0;k<N;k++)got+=(long double)full[row*N+k]*known[k];r[row]=got;
  double alpha=h*(i+.5),sig=.5*(1-std::cos(alpha)),z=-std::cos(Pi*(j+.5)/b),ds=.5*std::sin(alpha),dss=.5*std::cos(alpha);
  double sigp=.5*(1-std::cos(h*(std::min(a-1,i+1)+.5))),sigm=.5*(1-std::cos(h*(std::max(0,i-1)+.5)));
  double ps=(val(sigp,z)-val(sigm,z))/(2*h*ds),pss=(val(sigp,z)-2*val(sig,z)+val(sigm,z))/(h*h*ds*ds)-dss*ps/(ds*ds);
  double pz=(1+.3*sig+sig*sig)*(1+3*z*z),pzz=(1+.3*sig+sig*sig)*6*z;
  double psz=((1+.3*sigp+sigp*sigp)-(1+.3*sigm+sigm*sigm))*(1+3*z*z)/(2*h*ds);
  double t=hispid::AxisDerivatives::radial_t(sig),eta=hispid::AxisDerivatives::angular_eta(z),metric=s.b*s.b*(4*t/((1-t)*(1-t))+1-eta*eta);
  const auto&q=s.curved_symbols[(2*testmode+1)*N+i+a*j];
  double expected=metric*(q.zero*val(sig,z)+q.first[0]*ps+q.first[1]*pz+q.second[0]*pss+q.second[1]*pzz+q.mixed*psz);
  action_error=std::max(action_error,std::abs(double(got)-expected)/(1+std::abs(expected)));
 }
 // Independent full-matrix LU validates the block elimination, including
 // dense off-block mixed terms and transposed focus row replacements.
 for(int q=0;q<hispid::focus_rank;q++){
  int row=B.boundary_row(q);for(int k=0;k<N;k++)full[row*N+k]=B.focus_endpoint[q*N+k];
  long double v=0;for(int k=0;k<N;k++)v+=(long double)full[row*N+k]*known[k];r[row]=v;
 }
 auto F=gsl_matrix_view_array(full.data(),N,N);std::vector<size_t>piv(N);gsl_permutation perm{size_t(N),piv.data()};int sign;
 gsl_linalg_LU_decomp(&F.matrix,&perm,&sign);std::vector<double>direct=r;auto V=gsl_vector_view_array(direct.data(),N);gsl_linalg_LU_svx(&F.matrix,&perm,&V.vector);
 B.factor();auto block=r;B.solve_many(block.data(),1);double boundary[hispid::focus_rank];for(int q=0;q<hispid::focus_rank;q++)boundary[q]=r[B.boundary_row(q)];B.correct_focus(block.data(),boundary);
 double inverse_error=0;for(int k=0;k<N;k++)inverse_error=std::max(inverse_error,std::abs(block[k]-direct[k])/(1+std::abs(direct[k])));
 std::vector<double>scale(4*N*np),input(4*N*np),out(4*N*np,.125);
 for(size_t q=0;q<scale.size();q++){scale[q]=1+.001*(q%97);input[q]=.01*std::sin(.171*q)+.02*std::cos(.07*q);}
 auto W=puncture::upload(scale,"test scale"),I=puncture::upload(input,"test RHS"),O=puncture::upload(out,"test sentinel");
 PolarSpectralInverse inverse(s,W);inverse.apply(I,O);puncture::download(O,out.data());double bridge=0,unchanged=0;
 for(int k=0;k<np;k++)for(int v=0;v<4;v++){
  int m=k<=np/2?k:k-np/2;
  if(!v||m>4){for(int p=0;p<N;p++)unchanged=std::max(unchanged,std::abs(out[4*(p+N*k)+v]-.125));continue;}
  std::vector<double>projected(N);
  for(int i=0;i<a;i++)for(int j=0;j<b;j++){
   int p=i+a*j;long double sum=0;for(int l=0;l<np;l++)sum+=(long double)s.derivatives.forward[k*np+l]*input[4*(p+N*l)+v];projected[j+b*i]=double(sum)/scale[4*(p+N*k)+v];
  }
  const auto&factor=inverse.matrix.blocks[m];for(int q=0;q<hispid::focus_rank;q++)boundary[q]=projected[factor.boundary_row(q)];
  factor.solve_many(projected.data(),1);factor.correct_focus(projected.data(),boundary);
  for(int i=0;i<a;i++)for(int j=0;j<b;j++)bridge=std::max(bridge,std::abs(out[4*(i+a*j+N*k)+v]-projected[j+b*i])/(1+std::abs(projected[j+b*i])));
 }
 std::printf("spectral polar controls action=%.17g independent_inverse=%.17g bridge=%.17g untouched=%.17g\n",action_error,inverse_error,bridge,unchanged);
 return action_error<1e-10&&inverse_error<1e-9&&bridge<1e-9&&unchanged==0?0:1;
}
